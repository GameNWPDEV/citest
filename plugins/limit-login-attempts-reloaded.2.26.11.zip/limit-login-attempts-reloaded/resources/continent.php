<?php
return array (
	'AS' => __('Asia', 'limit-login-attempts-reloaded'),
	'AN' => __('Antarctica', 'limit-login-attempts-reloaded'),
	'AF' => __('Africa', 'limit-login-attempts-reloaded'),
	'EU' => __('Europe', 'limit-login-attempts-reloaded'),
	'NA' => __('North America', 'limit-login-attempts-reloaded'),
	'OC' => __('Oceania', 'limit-login-attempts-reloaded'),
	'SA' => __('South America', 'limit-login-attempts-reloaded'),
	'IC' => __('Intercontinental', 'limit-login-attempts-reloaded'),
	'ZZ' => __('Unknown', 'limit-login-attempts-reloaded'),
);